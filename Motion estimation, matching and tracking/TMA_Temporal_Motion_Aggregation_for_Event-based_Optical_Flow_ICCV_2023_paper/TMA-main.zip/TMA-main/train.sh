CUDA_VISIBLE_DEVICES=0 python train.py --checkpoint_dir 'ckpts/temp' --num_steps 200000 --batch_size 6 --lr 2e-4 #optional --wandb

